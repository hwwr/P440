var offlineConfig = {  // �豸����ʱ������
    "bgColor": "#AEAEAE"
    , "panel": {
        "p1": {
            "vUnit": ""
            , "vTitle": ""
            , "vContent": ""
        }
        , "p2": {
            "vUnit": ""
            , "vTitle": ""
            , "vContent": ""
        }
        , "p3": {
            "vUnit": ""
            , "vTitle": ""
            , "vContent": "�豸����"
        }
        , "connection": {
            "vUnit": ""
            , "vTitle": ""
            , "vContent": ""
        }
    }
};

var config = {  // �豸����ʱ������
    "bgColor": "#00C7B2"
    , "panel": {
        "p1": {
            "vUnit": ""   // ��λ
            , "vTitle": "����PM2.5" // ����
            , "vContent": getP1Content()   // ��������
        }
        , "p2": {
            "vUnit": ""
            , "vTitle": ""
            , "vContent": getP2Content()
        }
        , "p3": {
            "vUnit": ""
            , "vTitle": ""
            , "vContent": getP3Content()
        }
        , "connection": {
            "vUnit": ""
            , "vTitle": ""
            , "vContent": "<iconfont face='alink_iconfont'>&#x3011;</iconfont>"
        }
    }
};

function main() {
    if (model.data.onlineState.value == "on") {
        return JSON.stringify(config);
    } else {
        return JSON.stringify(offlineConfig);
    }
}

function getP1Content() {
    var ret = "";

    var value = 0;
    if (model.data.Status_AirQuality.value) {
        value = model.data.Status_AirQuality.value;
    } else {
        value = model.data.Status_AirQuality;
    }

    var values = ["1", "2", "3"];
    var valueLabels = ["��", "��", "��"];

    for (var i = 0; i < 3; ++i) {
        if (value == values[i]) {
            ret = valueLabels[i];
            break;
        }
    }

    return ret;
}

function getP2Content() {
    //var ret = "";
    var value = 0;
    if (model.data.OnOff_Power.value) {
        value = parseInt(model.data.OnOff_Power.value);
    } else {
        value = model.data.OnOff_Power;
    }
    var valueLabels = ["�ر�", "����"];
    return valueLabels[value];
}


function getP3Content() {
    var ret = "";

    var value = 0;
    if (model.data.WorkMode.value) {
        value = model.data.WorkMode.value;
    } else {
        value = model.data.WorkMode;
    }

    var values = ["1", "2", "3"];
    var valueLabels = ["�Զ�", "�ֶ�", "˯��"];

    for (var i = 0; i < 3; ++i) {
        if (value == values[i]) {
            ret = "ģʽ: " + valueLabels[i];
            break;
        }
    }

    return ret;
}