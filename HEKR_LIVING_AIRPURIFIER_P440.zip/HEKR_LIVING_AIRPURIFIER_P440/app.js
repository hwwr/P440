﻿require(['./main.js'],function(main){
//DA.uuid='123';
    /*电源组件*/
    var power = new DA.AlinkUI.Switch('power',{
        domhook:$('.bind_handle_switch'),
        datamodel:{
            title:'电源',
            subtitle:'',
            key:'OnOff_Power',
            value:"1",
            map:{on:'1',off:'2'},
            icon:'&#xe629'
        },
        tpl:'switchItem',
        changed: function(){
            this.setDeviceStatus();
            // main.statuFn();
        }
    });
    /*模式选择组件*/
    var grid = new DA.AlinkUI.Grid('grid2',{
        domhook : $('.bind_handle_grid2'),
        datamodel:{
            key:'WorkMode',
            gridNum:'3',
            value:'',
            uiTitle:'',
            map:[
                {
                    icon:'&#xe65d;',
                    txt:'自动',
                    value:'1'
                },
                {
                    icon:'&#xe609;',
                    txt:'手动',
                    value:'2'
                },
                {
                    icon:'&#xe64e;',
                    txt:'睡眠',
                    value:'3'
                }
            ]
        },
        changed:function(){
            this.setDeviceStatus();
        }
    });
    /*童锁组件*/
    var childLock = new DA.AlinkUI.Switch('childLock',{
        domhook:$('.childLock_switch'),
        datamodel:{
            title:'童锁',
            subtitle:'',
            key:'OnOff_ChildLock',
            value:"1",
            map:{on:'1',off:'2'},
            icon:'&#xe64c;'
        },
        tpl:'switchItem',
        changed: function(){
            this.setDeviceStatus();
            // main.statuFn();
        }
    });
    /*净化量组件*/
    var Capacity_TargetSlider = new DA.AlinkUI.Slider({
        name:'Capacity_TargetSlider',
        datamodel: {
            key: 'Ventilation_Speed'
        },
        sliderLabel: '设定净化量',
        element: '.bind_handle_Capacity_Target',
        value: "28",
        min: 0,
        max: 100,
        unit:'',
        step: 1,  //滑动时跳动的步长
        changed:function  () {
            var curSpeedValue = this.getValue();
                DA.setDeviceStatus(DA.uuid, {
                    "WorkMode":{
                     "value": "2"
                     },
                    "Ventilation_Speed": {
                        "value": curSpeedValue
                    }
                });
        }
    });
    /*负离子组件*/
    var ions =new DA.AlinkUI.Switch('ions',{
        domhook:$('.panel-ions'),
        datamodel:{
            title:'负离子',
            subtitle:'',
            key:'OnOff_Ions',
            value:"1",
            map:{on:'1',off:'2'},
            icon:'&#xe6bf;'
        },
        tpl:'switchItem',
        changed: function(){
            this.setDeviceStatus();
            // main.statuFn();
        }
    });
    /*定时预约*/
    var reservation =new DA.AlinkUI.ItemList('reservation',{
        domhook : $('.bind_reservation_list'),
        datamodel: {
            uiTitle:'',
            map: [{
                leftIcon:'&#x3044;',
                title: '定时预约',
                after:'',
                rightIcon:"&#xe617;"
            }]
        },
        onClickBefore:function(){
            return true;
        },
        onClickAfter:function(){
            return true;
        },
        onItemClick:function(targetItem,e){
            DA.nativeCmp.makeTimer({
                uuid: DA.uuid,
                sceneGroup: "OnOff_Power_A",
                type: ["on", "off"],
                actions: {
                    on: { // 关闭指令
                        OnOff_Power: {value: "1"}
                    },
                    off: { // 开启指令
                        OnOff_Power: {value: "2"}
                    }
                }
            }, function(d){
                // 可省略
                // success done;
            }, function(){
                // 可省略
                // failure done;
            });
        },
        change:function(){
            this.setDeviceStatus();
        }
    });
    var offNet = new DA.AlinkUI.OffNet('offNet1',{
        domhook : $('.bind_handle_offnet'),
        datamodel:{
            button:[]
        }
    });
    main.init();
});