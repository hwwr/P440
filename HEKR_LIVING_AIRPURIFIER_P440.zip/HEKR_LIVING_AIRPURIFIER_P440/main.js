define(['./status/status.js'],function(status){
    return{
        init:function(){
            var self =this;
            self.getDeviceStatus();
            self.bindPushData();
        },

        bindPushData:function(){
            var self =this;
            DA.bindPushData({
                'deviceStatusChange':function(data){
                    if(data){
                        self.iphoneOnlineFn();
                        var statusConfig = new DA.statusBar({
                                hook: '.statusX',
                                up :0,//0代表配置一个，1代表配置2个(此配置项横版时会用到，竖版不加)
                                attr: [
                                    {
                                        key: 'Ventilation_Speed',
                                        tpl: 'value-lable',
                                        valueLables: ["净化量"]
                                    },{
                                        key: 'WorkMode',
                                        values: ["1", "2", "3"],
                                        valueLables: ["自动", "手动", "睡眠"],
                                        tpl: 'value-lable'
                                    },{
                                        key:'Status_AirQuality',
                                        lable:'PM2.5',
                                        values: ["1", "2", "3"],
                                        valueLables: ["", "", ""],
                                        tpl:'value-lable'
                                    },{
                                        key: 'Status_AirQuality',
                                        values: ["1", "2", "3"],
                                        valueLables: ["优", "中", "差"],
                                        tpl: 'value-lable'
                                    }
                                ]
                            },
                            data);
                        self.statuFn(data);
                        self.renderD(data);
                        self.addStatuF();

                    }
                },
                netWorkStatusChange:function(data){}
            });
        },
        getDeviceStatus:function(){
            var self = this;
            DA.getDeviceStatus(DA.uuid,function(data){
                if(data){
                    self.onOffLineFn(data);
                    var statusConfig = new DA.statusBar({
                            hook: '.statusX',
                            up :0,//0代表配置一个，1代表配置2个(此配置项横版时会用到，竖版不加)
                            attr: [
                                {
                                    key: 'Ventilation_Speed',
                                    tpl: 'value-lable',
                                    valueLables: ["净化量"]
                                },{
                                    key: 'WorkMode',
                                    values: ["1", "2", "3"],
                                    valueLables: ["自动", "手动", "睡眠"],
                                    tpl: 'value-lable'
                                },{
                                    key:'Status_AirQuality',
                                    lable:'PM2.5',
                                    values: ["1", "2", "3"],
                                    valueLables: ["", "", ""],
                                    tpl:'value-lable'
                                },{
                                    key: 'Status_AirQuality',
                                    values: ["1", "2", "3"],
                                    valueLables: ["优", "中", "差"],
                                    tpl: 'value-lable'
                                }
                            ]
                        },
                        data);
                    self.addStatuF();
                    self.renderD(data);
                    self.navBarFn();
                    self.navImgFn();
                    self.statuFn(data);
                }
            })
        },
        /*获取数据，设置为最后一次的值*/
        renderD:function(data){
            var self = this;
            var sysPowerVa= data.OnOff_Power.value,/*电源值*/
                sysWorkMVa=data.WorkMode.value,/*工作模式值*/
                sysCapacitySVa=data.Ventilation_Speed.value,/*净化量值*/
                sysChildLVa=data.OnOff_ChildLock.value,/*童锁值*/
                sysIonsVa=data.OnOff_Ions.value;/*负离子模式值*/
            DA.getUI('grid2').setValue(sysWorkMVa);
            DA.getUI('power').setValue(sysPowerVa);
            DA.getUI('Capacity_TargetSlider').setValue(sysCapacitySVa);
            DA.getUI('childLock').setValue(sysChildLVa);
            DA.getUI('ions').setValue(sysIonsVa);
        },
        /*网络判断*/
        onOffLineFn:function(data){
            if(data.onlineState.value =='off'){
                DA.getUI('offNet1').showUI();
            }else{
                DA.getUI('offNet1').hideUI();
            }
        },
        /*手机网络判断*/
        iphoneOnlineFn:function(){
            if(DA.networkIsAvailable == true){
                DA.getUI('offNet1').hideUI();
            }else{
                DA.getUI('offNet1').showUI();
            }
        },
        /*状态栏 净化量*/
        addStatuF:function(){
            $('.statusX-label-up').append('<span class="navCap">净化量</span>')
        },
        /*电源开关 童锁*/
        statuFn:function(data){
            var self = this;
            //var curStatus = DA.getUI('power').getValue();
            var curLockVal = data.OnOff_ChildLock.value;
            var curStatus = data.OnOff_Power.value;
            if (curStatus == '1' && curLockVal== '0') {
                $('.panel-model').removeClass('hide').addClass('show');
                $('.panel-feature').removeClass('hide').addClass('show');
                $('.panel-childLock').removeClass('hide').addClass('show');
                $('.panel-power').removeClass('hide').addClass('show');
                $('.panel_powerOff').removeClass('show').addClass('hide');
                $('.panel-childBeLock').removeClass('show').addClass('hide');
            }else if(curStatus == '1' && curLockVal =='1'){
                $('.panel-childBeLock').removeClass('hide').addClass('show');
                $('.panel-model').removeClass('show').addClass('hide');
                $('.panel-feature').removeClass('show').addClass('hide');
                $('.panel-power').removeClass('show').addClass('hide');
            }else {
                $('.panel-power').removeClass('hide').addClass('show');
                $('.panel_powerOff').removeClass('hide').addClass('show');
                $('.panel-model').removeClass('show').addClass('hide');
                $('.panel-childLock').removeClass('show').addClass('hide');
                $('.panel-feature').removeClass('show').addClass('hide');
            }
        },
        /*toolBar 文字*/
        navBarFn:function(){
            DA.nativeCmp.topbar.setNavbar({
                title:DA.deviceName,
                type:'mixed',
                rightButton:[{
                    handler:function(){
                        $(document).on('click','.J_deviceback',function(){
                            DA.back();
                        })
                    }
                }]
            },function(){
                return true;
            },function(){
                return false;
            });
        },
        /*toolBar 图片*/
        navImgFn:function(){
            DA.getDeviceInfo({
                uuid: DA.uuid
            }, function(d) {
                if (d.result.msg === "success") {
                    $('.panel-img').css('background-image',"url("+d.result.data.image+")");
                } else {
                    // 可省略
                }
            });
        }
    }
});