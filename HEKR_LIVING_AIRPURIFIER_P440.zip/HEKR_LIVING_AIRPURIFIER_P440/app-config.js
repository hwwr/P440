﻿define(function() {
    //自动模式配置
    var deviceConfig = {};
    deviceConfig.components_key = ['OnOff_Power','Status_AirQuality.5','WorkMode'];
    deviceConfig.dashboard = {
        version: '2.0',
        attr:[
            {
                key: "OnOff_Power",
                label: "开关",
                values: ["1", "2"],
                template: 'power',
                position: ['home','device:power'],
                valueLabels: ["开", "关"]
            },
            {
                key: "Status_AirQuality",
                label: "室内PM2.5",
                template: "value_label",
                position: ['home'],
                values: ['1','2','3'],
                valueLabels: ['优','中','差']
            },
            {
                key: "WorkMode",
                label: "工作模式",
                template: "value_label",
                position: ['home'],
                values: ['1','2','3'],
                valueLabels: ['自动','手动','睡眠']
            }
        ]
    };
    return deviceConfig;
});
