// 本文件用于阿里版本统计和统一升级判断标准，重要的说三遍：不要删！不要删！不要删！！

{
	description: "用于阿里版本统计和统一升级判断标准",
	category: "AIRPURIFIER",
	versionStyle: "~2.0.0",
	scripts: {
	    sdk: "sdk/v2/sdk.js",
	    module: "sdk/v1/component.js"
	}
	versionTemplate: "1.0.0"
}